const { data } = useReadContract({
  address: MARKETPLACE_ADDRESS,
  abi: marketplaceAbi,
  functionName: "orderCounter",
});