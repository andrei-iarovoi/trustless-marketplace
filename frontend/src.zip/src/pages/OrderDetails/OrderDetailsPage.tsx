import { ArrowLeft, Calendar, CircleDollarSign, UserRound } from "lucide-react";
import { Link, useParams } from "react-router";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Container } from "@/components/ui/Container";
import { Badge } from "@/components/ui/badge";
import { mockOrders } from "@/data/mockOrders";
import { OrderActions } from "@/components/orders/OrderActions";

export function OrderDetailsPage() {
  const { orderId } = useParams();

  const order = mockOrders.find(
    (item) => item.id === Number(orderId)
  );

  if (!order) {
    return (
      <Container className="py-12">
        <Card className="mx-auto max-w-2xl">
          <CardContent className="py-10 text-center space-y-6">
            <h1 className="text-2xl font-bold">Order not found</h1>

            <Button asChild>
              <Link to="/marketplace">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Marketplace
              </Link>
            </Button>
          </CardContent>
        </Card>
      </Container>
    );
  }

  return (
    <Container className="space-y-8 py-12">
      <Button asChild variant="ghost">
        <Link to="/marketplace">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Marketplace
        </Link>
      </Button>

      <Card>
        <CardHeader className="flex flex-row items-start justify-between gap-6">
          <div>
            <CardTitle className="text-3xl">
              {order.title}
            </CardTitle>

            <p className="mt-2 text-slate-500">
              Escrow #{order.id.toString().padStart(3, "0")}
            </p>
          </div>

          <Badge>{order.status}</Badge>
        </CardHeader>

        <CardContent className="space-y-8">
          <div className="grid gap-4 md:grid-cols-2">
            <InfoCard
              icon={<CircleDollarSign className="h-5 w-5" />}
              label="Budget"
              value={`${order.budget} ETH`}
            />

            <InfoCard
              icon={<Calendar className="h-5 w-5" />}
              label="Deadline"
              value={order.deadline}
            />

            <InfoCard
              icon={<UserRound className="h-5 w-5" />}
              label="Buyer"
              value={order.buyer}
            />

            <InfoCard
              icon={<UserRound className="h-5 w-5" />}
              label="Seller"
              value={order.seller ?? "Not assigned"}
            />
          </div>
          <OrderActions status={order.status} />
        </CardContent>
      </Card>
    </Container>
  );
}

type InfoCardProps = {
  icon: React.ReactNode;
  label: string;
  value: string;
};

function InfoCard({
  icon,
  label,
  value,
}: InfoCardProps) {
  return (
    <div className="rounded-xl border p-5">
      <div className="mb-3 text-cyan-400">
        {icon}
      </div>

      <p className="text-sm text-muted-foreground">
        {label}
      </p>

      <p className="mt-1 break-all font-medium">
        {value}
      </p>
    </div>
  );
}